public class InchToCm implements IAggregable<InchToCm, Double>, IDeeplyCloneable<InchToCm> {
    private Double Value;

    public InchToCm(){}
    public InchToCm(Double X){
        Value = X;
    }
    public Double getValue(){
        return Value;
    }

    public Double aggregate(Double intermediateResult){
        if(intermediateResult == null){
            return Value;
        }else{
            return intermediateResult * 2.54;
        }
    }
    public InchToCm deepClone(){
        InchToCm sq1 = new InchToCm();
        sq1.Value = Value;
        return sq1;
    }


}
