public class AccountBalance implements IAggregable<AccountBalance, Integer>, IDeeplyCloneable<AccountBalance> {

    private Integer balance;

    public AccountBalance(){
    }

    public AccountBalance(Integer B ) {
        balance = B;
    }
    public Integer getBalance(){
        return balance;
    }


    public Integer aggregate(Integer intermediateResult){
        if(intermediateResult == null){
            return balance;
        }else{
           return balance + intermediateResult;
        }
    }
    public AccountBalance deepClone() {
        AccountBalance accountBalance = new AccountBalance();
        return accountBalance;
    }
}
