import org.junit.Assert;
import org.junit.Before;
import org.junit.jupiter.api.Test;


class InchToCmTest {
    private static final Double Val =25.4;
    private InchToCm eq = new InchToCm(Val);


    @Before
    public void before(){
        Assert.assertEquals(Val, eq.getValue());
    }

    @Test
     public void aggregate(){
        Assert.assertEquals(Val, eq.aggregate(10.0));
    }

    @Test
    public void deepClone(){
        InchToCm sq2 = eq.deepClone();
        Assert.assertNotEquals(sq2, eq);
    }


}