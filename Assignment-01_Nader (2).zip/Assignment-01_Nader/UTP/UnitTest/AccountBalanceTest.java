import org.junit.Assert;
import org.junit.Before;
import org.junit.jupiter.api.Test;

class AccountBalanceTest {

    private static final Integer Balance = 10;
    private static final Integer TOTAL = 20;
    private AccountBalance account = new AccountBalance(Balance);

    @Before
    public void before(){
        Assert.assertEquals(Balance, account.getBalance());
    }

    @Test
    public void aggregate(){
        Assert.assertEquals(TOTAL, account.aggregate(10));
    }

    @Test
    public void deepClone(){
        AccountBalance a2 = account.deepClone();
        Assert.assertNotEquals(a2, account);
    }
}