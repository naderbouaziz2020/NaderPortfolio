import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;


class ContainerTest {


    private static final InchToCm[] _area = new InchToCm[]{new InchToCm(10.0), new InchToCm(2.0)};
    private static final AccountBalance[] _horse = new AccountBalance[]{new AccountBalance(50), new AccountBalance(50)};

    private static Container<InchToCm, Double> InchToCmContainer;
    private static Container<AccountBalance, Integer> AccBalContainer;

    @BeforeEach
    public void before(){
        InchToCmContainer = new Container<>(_area);
        AccBalContainer = new Container<>(_horse);
    }
    @Test
    public void aggregate(){
        Double CmVal = 10 * 2.54;
        Integer AccBall = 100;
        assertArrayEquals(_area, InchToCmContainer.element().toArray());
        assertArrayEquals(_horse, AccBalContainer.element().toArray());

        assertEquals(CmVal, InchToCmContainer.aggregateAllElements());
        assertEquals(AccBall, AccBalContainer.aggregateAllElements());
    }

    @Test
    public void cloneElements(){
        InchToCm areaClone = InchToCmContainer.cloneElementAtIndex(100);
        AccountBalance horseClone = AccBalContainer.cloneElementAtIndex(0);

        assertNotSame(InchToCmContainer.element().get(0), areaClone);
        assertNotSame(AccBalContainer.element().get(0), horseClone);
    }

}